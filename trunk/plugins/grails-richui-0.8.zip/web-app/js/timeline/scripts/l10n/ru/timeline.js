﻿/*==================================================
 *  Common localization strings
 *==================================================
 */

Timeline.strings["ru"] = {
    wikiLinkLabel:  "обсудите"
};

