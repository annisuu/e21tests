/*==================================================
 *  Localization of labellers.js
 *==================================================
 */

/* The Dutch do not capitalize months
*/

Timeline.GregorianDateLabeller.monthNames["nl"] = [
 "jan", "feb", "mrt", "apr", "mei", "jun", "jul", "aug", "sep", "okt", "nov", "dec"
];
